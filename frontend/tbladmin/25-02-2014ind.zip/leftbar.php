  <div class="leftpanel">
        
        <div class="leftmenu">        
            <ul class="nav nav-tabs nav-stacked">
            	<li class="nav-header">Navigation</li>
                <li class="active"><a href="index.php"><span class="iconfa-laptop"></span> Dashboard</a></li>
             
                <li><a href="comment.php"><span class="iconfa-calendar"></span> Profile Approval</a></li>
                
                <li class="dropdown"><a href="#"><span class="iconfa-th-list"></span>Users</a>
                	<ul>
                    	<li><a href="index.php">All Users</a></li>
                            <li><a href="active.user.php">Activate Users</a></li>
                                <li><a href="inactive.user.php">Blocked Users</a></li>
                       
                    </ul>
                </li>
                
                <li class="dropdown"><a href="#"><span class="iconfa-envelope"></span>Bill</a>
                    <ul>
                        <li><a href="bill.php">View All</a></li>
                        <li><a href="suppbill.php">Support Cause</a></li>
                       <li class="dropdown"><a href="#">Add New</a>
                        <ul>
                            <li><a href="addbill.php?name=Regular">Regular Bill</a></li>
                            <li><a href="addbill.php?name=Big">Big Bill</a></li>
<li><a href="add.bill.php?name=Appropriations">Appropriations Bill</a></li>
                        </ul>
                     </li>
                    </ul>
                </li>
                <li><a href="comment.php"><span class="iconfa-calendar"></span> Reported Comments</a></li>
                 <li><a href="comment.php"><span class="iconfa-calendar"></span> About</a></li>
                
 <li><a href="comment.php"><span class="iconfa-calendar"></span> Contact</a></li>
                
<li><a href="addnews.php"><span class="iconfa-calendar"></span> News</a></li>
  
<li class="dropdown"><a href="#"><span class="iconfa-th-list"></span>Proposal</a>

                	<ul>
                    	<li><a href="index.php">Content</a></li>
                            <li><a href="#">Users Proposal</a></li>
                    </ul>
                </li>
                
              
            </ul>
        </div><!--leftmenu-->
        
    </div><!-- leftpanel -->