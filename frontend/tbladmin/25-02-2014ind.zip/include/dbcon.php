<?php
//$db_conx = mysqli_connect("thefourthbranch.db.11457088.hostedresource.com", "thefourthbranch", "Computer123A@", "thefourthbranch");
// Evaluate the connection
$con = mysqli_connect("localhost", "tbldev1_fourth", "Fr1234RA[-", "tbldev1_fourth");
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
?>